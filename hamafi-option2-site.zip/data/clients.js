export const clients = [
  { name: "Louis Vuitton" },
  { name: "Tiffany & Co." },
  { name: "Tom Ford" },
  { name: "Brunello Cucinelli" }
];
