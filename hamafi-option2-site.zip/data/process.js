export const processSteps = [
  { n: "01", title: "Receive Brand Concept & Brief" },
  { n: "02", title: "Plan Production & Materials (MDF, Acrylic, etc.)" },
  { n: "03", title: "Create and Assemble in Our Workshop" },
  { n: "04", title: "Install On‑Site with Precision & Care" }
];
